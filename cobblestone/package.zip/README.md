# cobblestone
Fork of harmony by EyeScary development, replaced syntax highlighting with lead markdown renderer to turn into notes app
basically it just refactored harmony to make all mentions of harmony cobblestone, all mentions of eyescary development pittab, and removed a bunch of "unnecessary shit"

## ESMusic TUI
wow a tui version of ESMusic, how self explanatory (btw when it makes its debut you should install it through AGPM)

## Terms
This software is provided as is, with no warranty or license, we would like credit if you use my/developers of this software's code for profit, but to all other intents and purposes, this is usable anywhere and is open source. I will take time to read your pull requests if you think you have a contribution, but I retain the right to reject any pull requests I want

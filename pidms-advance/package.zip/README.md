# pidms-advance
Collection of pidms games with various difficulties, some derived from other projects, oh yeah and a tutorial cause the controls are So DifFiCuLT

# what is pidms?

pidms is a free to play microgame about fighting slimes. It is effectively the demo version of our in development game, padms. Padms will be available soon and have futher features over pidms like an inventory, bossfights and different locations. Oh yeah, and the ability to actually save your game

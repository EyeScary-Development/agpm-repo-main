#Harmony NEW code editor core version 1.0.1 for Harmony 0.7
#Copyright Eyescary development 2026
#Modified? [x]

# imports
import extensions
import os

# put your imports here
from consts import PLATFORM

class editor:
    def openfile(filename):
        try:
            with open(filename, "r") as file:
                return file.readlines()
        except:
            return []
        
    def write(self, filename):
        with open(filename, "w") as file:
            for item in self.lines:
                file.write(item)

    def printfilecore(self):
        linenum = 1
        for item in self.lines:
            print(str(linenum)+"|"+item, end="")
            linenum+=1

    def main(self):
        os.system("cls" if os.name == "nt" else "clear")
        extensions.printfile(self.extension, self.lines)
        userInput=input("|")
        if userInput.startswith(":"):
            self.lines = extensions.commands(userInput.strip(), self.lines, self.filename, self.extension)
        else:
            self.lines.append(userInput+'\n')
        editor.write(self, self.filename)

    def __init__(self):
        if extensions.checksetting(1):
            print("here is a list of files in the current directory:")
        if PLATFORM == "Windows":
            os.system("dir")
        else:
            os.system("ls -A")
        name=input("what is the name of the file you wish to edit?: ")
        if "." in name:
            self.extension = "." + name.split(".")[1]
            self.filename = name
        else:
            self.extension = input("what is the extension of the file?: ")
            if not self.extension.startswith("."):
                self.extension = "." + self.extension
            self.filename = name + self.extension
        print(self.filename, self.extension)
        self.lines = editor.openfile(self.filename)
        

def main():
    instance = editor()
    while True:
        instance.main()

if __name__ == "__main__":
    main()
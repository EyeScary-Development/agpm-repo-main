import platform

PLATFORM = platform.system()
# AGPM
Actually good package manager

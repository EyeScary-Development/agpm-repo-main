print("so you chose tutorial, wise choice")
input("press 1 to attack: ")
input("press 2 to heal (in some difficulties only): ")
input("press 3 if you want to run away (exit the game): ")
print("In difficulty easy, you can attack or run, damage amounts are set, the slime can't attack you and the slime is 2 hit. In regular difficulty, healing becomes an option and the slime wil randomly attack you. In hard difficulty, you and the slime have very similar hp and attack damage. You can also miss your shots. \n \n")
input("press enter when you are done reading: ")

import menu
